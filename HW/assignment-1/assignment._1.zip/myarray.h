

int binarySearch(int arr[], int size, int target, int *numComparisons);
int linearSearch(int arr[], int size, int target, int *numComparisons);
void sortArray(int arr[], int size);
void copyArray(int fromArray[], int toArray[], int size);
